# Guess The Number

A simple guess the number game made in Java.  

## Installation
**__Installing the files__**
```cmd
git clone https://github.com/Atidipt123/guess-the-number.git
cd guess-the-number
```
After this make a project using your ide with the path of the cloned folder. Make sure you have Java installed.

## Playing the game
Just run Main.java-

## Contributors
[Atidipt123](https://github.com/Atidipt123)

